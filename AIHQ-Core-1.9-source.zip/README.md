# AI Headquarters Core 1.9

Source snapshot of the local AI Headquarters application. This archive does not contain user records, project-run logs, workspace backups, model weights, credentials or the Ollama runtime.

## Running

Requires Node.js 22 or newer and Ollama on 127.0.0.1:11434 with qwen3:4b-instruct installed. Start Ollama, then run from the extracted project folder:

    node work/local-server.cjs

Open http://127.0.0.1:8787 . The included start-hq.cjs helper expects the portable Ollama installation under work/ollama and model files under work/ollama-models, matching the existing local setup; these large dependencies are not included.

GitHub Pages can show the static interface but cannot run this backend or its AI workflows. Keep the backend bound to localhost. The dedicated tour preview uses an authored template with restricted Matterport/3DVista frames; arbitrary generated HTML remains in a separate sandbox.

## Checks

Run the included work/test-*.cjs and work/check.cjs scripts from the project folder. Tests using mocked model responses check workflow logic, not model accuracy. Actual outputs need human review.

See CHANGELOG-bg.md for Bulgarian release notes and limitations.
