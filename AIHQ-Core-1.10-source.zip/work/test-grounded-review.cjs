const assert=require('assert'),{validateReview,explicitFormatIssues}=require('./quality-rules.cjs');const task='Напиши точно две точки. Използвай само предоставените факти.',result='1. Продажба.\n2. Наем.';
assert(validateReview({decision:'REVIEW',issues:[]},{task,result}).valid);
assert(!validateReview({decision:'FIX',issues:[{quote:'Продажба.',criterion:'Добави телефон и цена',problem:'Липсват контакти'}]},{task,result}).valid);
assert(!validateReview({decision:'FIX',issues:[{quote:'Несъществуващ текст',criterion:'точно две точки',problem:'Грешка'}]},{task,result}).valid);
assert(!validateReview({decision:'REVIEW',issues:[{quote:'Продажба.',criterion:'точно две точки',problem:'Грешка'}]},{task,result}).valid);
assert.equal(explicitFormatIssues(task,result).length,0);assert.equal(explicitFormatIssues(task,'1. Само една точка.').length,1);
assert.equal(explicitFormatIssues('Напиши кратък текст.','Кратък текст.').length,0);
console.log('PASS: invented criteria, nonexistent quotes and contradictory reviews are rejected; explicit list length is checked without inventing requirements');

assert.equal(explicitFormatIssues('Точно две точки. Без допълнителни раздели.','Заглавие\n1. Продажба.\n2. Наем.').length,1);
assert.equal(explicitFormatIssues('Точно две точки. Без допълнителни раздели.','1. Продажба.\n2. Наем.').length,0);

const {normalizeRequestedFormat}=require('./quality-rules.cjs');assert.equal(normalizeRequestedFormat('Точно две точки. Без допълнителни раздели.','Увод\n1. Продажба.\n2. Наем.'),'1. Продажба.\n2. Наем.');assert.equal(normalizeRequestedFormat('Точно две точки. Без допълнителни раздели.','Увод\n1. Само една.'),'Увод\n1. Само една.');
