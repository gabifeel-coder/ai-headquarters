const {spawn}=require('child_process'),fs=require('fs'),path=require('path');
const root=__dirname;
async function alive(url){try{return (await fetch(url,{signal:AbortSignal.timeout(1500)})).ok}catch{return false}}
function launch(exe,args,log,env=process.env){const fd=fs.openSync(path.join(root,log),'a');spawn(exe,args,{cwd:root,env,detached:true,windowsHide:true,stdio:['ignore',fd,fd]}).unref();fs.closeSync(fd)}
(async()=>{if(!await alive('http://127.0.0.1:11434/api/version'))launch(path.join(root,'ollama','ollama.exe'),['serve'],'ollama-start.log',{...process.env,OLLAMA_MODELS:path.join(root,'ollama-models'),OLLAMA_HOST:'127.0.0.1:11434',OLLAMA_NO_CLOUD:'1'});if(!await alive('http://127.0.0.1:8787/api/local-status'))launch(process.execPath,[path.join(root,'local-server.cjs')],'hq-start.log');console.log('Open http://127.0.0.1:8787')})().catch(e=>{console.error(e);process.exitCode=1});
