const assert=require('assert'),engine=require('./agent-engine.cjs');
const report={pages:[{text:'Public contact team@example.org; +359 879 685 883.'}]};
assert(engine.contactFacts(report).emails.includes('team@example.org'));
assert.equal(engine.factualChecks('<html><body>team@example.org +359 879 685 883</body></html>',report).length,0);
assert(engine.factualChecks('<html><body>fake@example.org 0891 234 567</body></html>',report).length>=2);
assert(engine.factualChecks('<html><body><img src="https://example.org/photo.jpg"></body></html>',report).some(x=>x.includes('image')));
assert(engine.factualChecks('<html><body>Цена 200 000 евро</body></html>',report).some(x=>x.includes('catalog')));
assert(engine.inspectHTML('<html><body><nav><a href="#missing">Page</a></nav></body></html>').some(x=>x.includes('target')));
console.log('PASS: unsupported contacts, unconnected price catalog, external images and missing navigation targets are flagged');
