const fs=require('fs'),vm=require('vm'),assert=require('assert');
const source=fs.readFileSync('work/ai-headquarters/index.html','utf8').match(/<script>([\s\S]*?)<\/script>/)[1];
const elements=new Map(),listeners={};
const el=id=>{if(!elements.has(id))elements.set(id,{value:'',hidden:true,dataset:{},classList:{toggle(){}},addEventListener(){},insertAdjacentHTML(position,text){this.innerHTML+=text},focus(){},innerHTML:'',textContent:''});return elements.get(id)};
let saved;
const context=vm.createContext({console,Intl,Date,Math,JSON,Object,String,Number,Array,Set,Error,crypto:require('crypto').webcrypto,setTimeout:()=>1,clearTimeout(){},localStorage:{getItem:()=>null,setItem:(k,v)=>saved=JSON.parse(v)},document:{getElementById:el,querySelector:el,querySelectorAll:()=>[],addEventListener:(name,fn)=>listeners[name]=fn},window:{scrollTo(){}},history:{replaceState(){}},location:{hash:'',protocol:'https:',hostname:'example.com',port:''}});
vm.runInContext(source.slice(0,source.lastIndexOf('fillStudio();renderRobots();render();')),context);
assert.equal(vm.runInContext('AGENTS.length',context),24);
assert.equal(vm.runInContext('new Set(AGENTS.map(a=>a.id)).size',context),24);
assert(vm.runInContext("['legal','compliance','ip'].every(id=>AGENTS.some(a=>a.id===id))",context));
vm.runInContext(`
state.projects=[{id:'p1',name:'Original',description:'Old',createdAt:'2026-10-19'}];
state.tasks=[{id:'t1',title:'Original task',description:'Old brief',projectId:'p1',agentId:'director',status:'done',createdAt:'2026-10-19'}];
state.leads=[{id:'l1',name:'Client',amount:100,status:'offer'}];
render=()=>{};
modal('task',{id:'t1'});
if($('mName').value!=='Original task')throw Error('Task fields not loaded');
$('mName').value='Updated task';$('mDesc').value='Updated brief';$('mProject').value='p1';$('mAgent').value='developer';$('mAcceptance').value='Deliver a working page';$('mResult').value='A delivered result';$('mReview').value='Claude: fix the heading';saveModal();
modal('project',{id:'p1'});$('mName').value='Updated project';$('mDesc').value='Updated description';saveModal();
`,context);
assert.equal(saved.tasks.length,1);assert.equal(saved.tasks[0].title,'Updated task');assert.equal(saved.tasks[0].status,'todo');assert.equal(saved.tasks[0].createdAt,'2026-10-19');assert.equal(saved.tasks[0].agentId,'developer');assert.equal(saved.projects.length,1);assert.equal(saved.projects[0].name,'Updated project');
listeners.change({target:{matches:selector=>selector==='[data-lead-status-id]',dataset:{leadStatusId:'l1'},value:'paid'}});
assert.equal(saved.leads[0].status,'paid');
assert.equal(saved.tasks[0].acceptance,'Deliver a working page');assert.equal(saved.tasks[0].result,'A delivered result');assert.equal(saved.tasks[0].review,'Claude: fix the heading');
assert(vm.runInContext('preparedReview(state.tasks[0])',context).includes('A delivered result'));
assert(vm.runInContext('preparedTask(state.tasks[0])',context).includes('Deliver a working page'));
context.backup=JSON.stringify(saved);
assert.equal(vm.runInContext('normalize(JSON.parse(backup)).tasks[0].review',context),'Claude: fix the heading');
assert.equal(vm.runInContext('normalize({version:1,projects:[],tasks:[{id:"old",title:"Legacy",status:"todo",agentId:"director"}],leads:[]}).tasks[0].result',context),'');
console.log('PASS: edits preserve IDs and creation date, and reopen accepted tasks for review; business status saves.');
console.log('PASS: criteria, results and review notes survive backup reload; old backups load; AI briefs include saved data.');

vm.runInContext('viewResult(state.tasks[0])',context);assert.equal(el('.app').inert,true);assert.equal(el('modalSubmit').hidden,true);assert(el('modalForm').innerHTML.includes('A delivered result'));vm.runInContext('closeModal()',context);assert.equal(el('.app').inert,false);assert.equal(el('modalSubmit').hidden,false);console.log('PASS: result reader and modal focus isolation');

assert.equal(vm.runInContext('normalize({version:1,projects:[],tasks:[],leads:[]}).runs.length',context),0);
vm.runInContext("const testJob={id:'11111111-1111-4111-8111-111111111111',projectId:'p1',name:'Website',brief:'Goal',status:'review',createdAt:'2026-10-27',updatedAt:'stamp1',steps:[{key:'plan',role:'director',result:'Plan'}],sources:[],events:[]};updateRunTask(testJob);state.tasks.find(x=>x.autoRunId===testJob.id).status='done';updateRunTask(testJob);",context);
assert.equal(vm.runInContext("state.tasks.find(x=>x.autoRunId===testJob.id).status",context),'done');
console.log('PASS: old backups load without run history; polling preserves accepted workflow results');

assert.match(vm.runInContext("completionProblem({result:'',internet:false})",context),/резултат/);
assert.equal(vm.runInContext("completionProblem({result:'Actual output',internet:false})",context),'');
assert.match(vm.runInContext("completionProblem({result:'Claimed research',internet:true,sources:'[]'})",context),/източници/);
assert.match(vm.runInContext("completionProblem({result:'Draft',autoRunId:'missing',artifactUrl:''})",context),/чернова/);
assert.equal(vm.runInContext("normalize({version:1,projects:[],tasks:[],leads:[],runs:[{id:'11111111-1111-4111-8111-111111111111',projectId:'p1',status:'queued'}]}).runs[0].status",context),'queued');
console.log('PASS: empty results, unsupported research and unfinished project runs cannot be accepted; queued state survives backups');


vm.runInContext("state.tasks[0].versions=[];snapshotTask(state.tasks[0]);state.tasks[0].result='New version';snapshotTask(state.tasks[0]);",context);
assert.equal(vm.runInContext("state.tasks[0].versions.length",context),2);
assert.equal(vm.runInContext("normalize(JSON.parse(JSON.stringify(state))).tasks[0].versions.length",context),2);
assert.equal(vm.runInContext("draftURL('/tour-preview/11111111-1111-4111-8111-111111111111')",context),'/tour-preview/11111111-1111-4111-8111-111111111111');
console.log("PASS: result versions survive backup roundtrip; dedicated tour previews are recognized");
