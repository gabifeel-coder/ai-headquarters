const assert=require('assert'),fs=require('fs'),vm=require('vm');
const {tourSource,renderTourSite}=require('./tour-renderer.cjs');
for(const url of ['http://my.matterport.com/show/?m=abcdefgh','https://my.matterport.com.evil.test/show/?m=abcdefgh','https://u:p@my.matterport.com/show/?m=abcdefgh','https://127.0.0.1/','https://storage.net-fs.com/hosting/1/2/?token=abc','javascript:alert(1)'])assert.throws(()=>tourSource({url}));
assert.equal(tourSource({url:'https://my.matterport.com/show/?m=abcdefgh&secret=discard'}).url,'https://my.matterport.com/show/?m=abcdefgh');
assert.equal(tourSource({url:''}).mode,'pending');const tour=tourSource({mode:'demo'}),html=renderTourSite({name:'<script>alert(1)</script>',brief:'<img src=x onerror=alert(1)>',tour});assert(!html.includes('<img src=x'));assert(html.includes('Не е имот на')||html.includes('Не е имот')||html.includes('Не е')||html.includes('Не е'.toLowerCase()));assert(!/<iframe[\s>]/.test(html),'Remote content must load only after click');
for(const script of html.matchAll(/<script>([\s\S]*?)<\/script>/g))new vm.Script(script[1]);
const pending=renderTourSite({name:'Pending',tour:tourSource({url:''})});assert(!pending.includes('id="loadTour"'));assert(pending.includes('няма реално заснемане'));
const page=fs.readFileSync('work/ai-headquarters/index.html','utf8');assert(page.includes("kind:p.kind||'website'"));assert(page.includes('Върни за поправка'));assert(page.includes('snapshotTask(current)'));
console.log('PASS: tour URLs are restricted and normalized; unsafe content escaped; remote tour waits for explicit click; missing materials never become a fabricated tour');
