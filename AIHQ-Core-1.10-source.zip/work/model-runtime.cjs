const fs=require('fs'),path=require('path');
const file=path.join(__dirname,'model-settings.json'),allowed=['qwen3:4b-instruct','qwen3:8b','gemma3:4b'];
function settings(){let s={};try{s=JSON.parse(fs.readFileSync(file,'utf8'))}catch{}return {model:allowed.includes(s.model)?s.model:'qwen3:4b-instruct',reviewModel:allowed.includes(s.reviewModel)?s.reviewModel:'qwen3:4b-instruct',thinking:false,context:8192}}
module.exports={settings,allowed};
