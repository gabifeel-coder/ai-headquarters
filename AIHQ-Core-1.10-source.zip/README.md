# AI Headquarters Core 1.10

Source-only snapshot of the local Windows application. Excludes user data, financial journals, account references, encryption keys, backups, project runs, model weights, executable runtimes and logs.

## Requirements

Node.js 22+, Ollama, and the local models gemma3:4b and qwen3:4b-instruct. With a normal Ollama installation, pull those model tags, start Ollama on 127.0.0.1:11434, and run from this project folder:

    node work/local-server.cjs

Open http://127.0.0.1:8787 . Text inference uses localhost only. The separate model-settings.json selects the local writer and reviewer. The included start-hq helper expects portable Ollama under work/ollama and model files under work/ollama-models; these large dependencies are not included.

## Local video runtime

The MP4 workflow requires Windows and the FFmpeg essentials build linked by ffmpeg.org at https://www.gyan.dev/ffmpeg/builds/ . The included download-video-mirror.cjs downloads the 9.0.2 release from that vendor GitHub mirror and verifies its SHA-256 release digest. Extract the verified ZIP under work/ffmpeg, retaining the version-folder/bin layout. Arial is read from the Windows fonts directory; it is not redistributed here. Video mode currently generates silent portrait text-motion videos, not filmed footage or speech.

## Tests

Run the included work/test-*.cjs and work/check.cjs from the project folder. The video renderer test needs FFmpeg. The benchmark needs the local models. Mock-model tests verify workflow logic, not expertise or general model accuracy.

## Private local state

Financial account references are stored locally with AES-GCM. The local key is beside local data; this is not protection from an attacker with full filesystem access. The journal is a manually documented record, not verified bank funds. Investment orders are paper-only; no real brokerage or payment operator is connected. Full account references and keys are excluded from journal export and from this archive.

Do not expose this local server publicly. It binds to localhost and does not implement a hosted multi-user financial service. GitHub Pages can show a static interface but cannot run this backend. Publishing, actual sales, payment receipt and real trading still need proper service connections and user setup.

See CHANGELOG-bg.md for functionality, observed tests and limits.
